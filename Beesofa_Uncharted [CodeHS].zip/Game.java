import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import Abilities.*;
import Entities.*;


/* Created on January 24th, 2025 as a personal project
Stopped work on May 14th, 2025, then came back to it on January 8th, 2026*/
public class Game
{
    static boolean gameRunning = true;
    static String choose = "";
    static int tPhase = 0; // turn Phase, 0 = option, 1 = choose enemy, 2 = damage calculation
    static int[] chosenOption = new int[2];
    
    static boolean optionChosen = false;
    static int chosenEnemy = 0;
    static int chosenAbility = 0;
    static int floorNum = 1;
    static int turnNum = 1;
    static int skillState = 0; // 0 = fail, 1 = late, 2 = hit, 3 = crit
    static int playerDMG = 0;
    static int enemyDMG = 0;
    
    static boolean skillCheck = false;
    static boolean attacking = false;
    static boolean AOE = false;
    
    static Scanner input = new Scanner(System.in);
    static Random random = new Random();
    
    static ArrayList<Enemy> enemyParty = new ArrayList<Enemy>();
    static Enemy e1 = new Enemy("Skeleton", 3, 1, 0);
    static Enemy e2 = new Enemy("Pirate", 6, 1, 0);
    
    static Player player = new Player("Pringle", "( ^ – ^ )", 15, 10);
    static ArrayList<Ability> moveset = new ArrayList<Ability>();
    static ArrayList<Ability> choices = new ArrayList<Ability>();
    
    static Slash slash = new Slash();
    static Block block = new Block();
    static Recover recover = new Recover();
    static BigShot bigShot = new BigShot();
    static Bomb bomb = new Bomb();
    static Counter counter = new Counter();
    
    public static void main(String[] args) {
        System.out.print("After using an ability and / or selecting an enemy, you will be given a letter. ");
        System.out.println("Type this letter as fast as possible to attack, or even critical hit!");
        System.out.println();
        long startTime = System.currentTimeMillis();
        
        enemyParty.add(e1);
        enemyParty.add(e2);
        moveset.add(slash);
        moveset.add(block);
        moveset.add(recover);
        
        choices.add(bigShot);
        choices.add(bomb);
        choices.add(counter);
        
        // GAME
        while (gameRunning) {
            skillState = 0;
            player.setDMG(0);
            player.setDEF(0);
            chosenAbility = -1;
            chosenEnemy = -1;
            attacking = false;
            // User chooses an ability to use
            while (chosenAbility <= -1) {
                System.out.print("Floor " + floorNum + " | ");
                System.out.println("Turn " + turnNum);
                for (Enemy en : enemyParty) {
                    en.printStatus(getEnemyOrder(en.getName()));
                }
                player.printStatus();
                for (Ability ability : moveset) {
                    System.out.println("[" + (moveset.indexOf(ability) + 1) + "]" + " " + ability);
                    
                }
                System.out.print("Select an ability: ");
                choose = input.nextLine();
                
                chosenOption[tPhase] = playerIntChoose(choose);
                for (Ability ability : moveset) {
                    if (chosenOption[tPhase] == moveset.indexOf(ability) + 1 && chosenOption[tPhase] < moveset.size() + 1
                    && ability.enoughMana(player.getMana()) ) {
                        chosenAbility = moveset.indexOf(ability);
                        conditionFromAbility(ability);
                        int mp = player.getMana() - getAbility().getCost();
                        player.setMana(mp);
                        break;
                    }
                }
                if (chosenOption[tPhase] == 2763 || chosenOption[tPhase] == 666) {
                    tPhase = 0;
                    break;
                }
                else if (chosenOption[tPhase] >= 0 && attacking) {
                    tPhase = 1;
                    break;
                }
                System.out.println();
            }
            // User chooses an enemy to attack
            while (chosenEnemy <= -1 && attacking && !AOE) {
                System.out.print("Select an enemy: ");
                choose = input.nextLine();
                chosenOption[tPhase] = playerIntChoose(choose);
                chosenOption[tPhase]--;
                for (Enemy en : enemyParty) {
                    if (chosenOption[tPhase] == enemyParty.indexOf(en) && !en.isDead()) {
                        System.out.println(en.getName());
                        chosenEnemy = chosenOption[tPhase];
                        optionChosen = true;
                        break;
                    }
                }
                
            }
            
            // Checks if user inputs a "cheat code"
            if (chosenOption[tPhase] == 2763) {  // Ends game
                gameRunning = false;
                break;
            }
            else if (chosenOption[tPhase] == 666) {  // Kills all enemies
                for (Enemy en : enemyParty) {
                    en.setHP(0);
                }
            } 
            
            // Checks if ability requires a skill check
            if (skillCheck) {
                System.out.println();
                skillState = doSkillCheck(getAbility() );
                optionChosen = true;
            }
            // ABILITY CALCULATIONS
            if (chosenAbility > -1 && chosenAbility <= moveset.size() ) {
                useAbility();
            }
            
            // Checks if ability will deal damage to all enemies
            if (AOE && attacking && player.getDMG() >= 1) {
                for (Enemy en : enemyParty) {
                    takeDamage(en, player);
                }
            }
            // Single-target damage towards an enemy
            if (chosenEnemy > -1 && player.getDMG() >= 1) {
                takeDamage(getEnemy(), player);
            }
            
            // Each enemy deals damage to player
            for (Enemy en : enemyParty) {
                if (en.getDMG() >= 1 && en.getHP() > 0) {
                    int value = (int)(en.getDMG() * Math.ceil(en.rollCrit(1.5, 50)) ) - player.getDEF();
                    takeDamage(player, en);
                }
            }
            player.setDMG(0);
            player.setDEF(0);
            
            // Checks if all enemies are below 0 health
            if (isEnemyDead()) {
                nextFloor();
                player.setMana(player.getMaxMana() );
                player.setHP(player.getMaxHP() );
                continue;
            }
            deathPlayer();
            
            // Checks if user input is invalid
            if (! optionChosen) {
                    System.out.println("Invalid option");
                }
            else {
                tPhase = 0;
                turnNum++;
            }
            optionChosen = false;
            
            System.out.println("\n");
            
        }
        
        // End of run
        double timeSpent = durationInSec(startTime);
        System.out.println(timeSpent + " seconds total spent on this run");
    }
    
    
    // ABILITY FUNCTIONS
    public static void useSlash() {
        player.addDMG( slash.useAbility(skillState) );
    }
    public static void useBlock() {
        player.addDEF( block.useAbility(skillState) );
        player.setMana( player.getMana() + (int)block.getValue()*2 );
    }
    public static void useRecover() {
        player.addHP( recover.useAbility(skillState) );
    }
    public static void useBigShot() {
        player.addDMG( bigShot.useAbility(skillState) );
    }
    public static void useBomb() {
        player.addDMG( bomb.useAbility(skillState) );
    }
    public static void useCounter() {
        int value = counter.useAbility(skillState);
        if (value > 0) {
            player.addDEF(value);
        }
        for (Enemy en : enemyParty) {
            player.addDMG( (int)(en.getDMG() * (value/2)) );
        }
    }
    
    
    // FUNCTIONS
    public static void useAbility() {
        String name = getAbility().getName();
        if (name == slash.getName() ) {
            useSlash();
        }
        else if (name == block.getName() ) {
            useBlock();
        }
        else if (name == recover.getName() ){
            useRecover();
        }
        else if (name == bigShot.getName() ) {
            useBigShot();
        }
        else if (name == bomb.getName() ) {
            useBomb();
        }
        else if (name == counter.getName() ) {
            useCounter();
        }
    }
    
    // Returns the currently selected enemy
    public static Enemy getEnemy(){
        return enemyParty.get(chosenEnemy);
    }
    // Returns the currently selected ability
    public static Ability getAbility() {
        return moveset.get(chosenAbility);
    }
    
    // Damage
    public static void takeDamage(Entity entity, Entity attacker) {
        int value = attacker.getDMG() - entity.getDEF();
        if (attacker.getDMG() >= 1) {
            entity.subHP(value);
            if (value < 0) {
                value = 0;
            }
            System.out.println(attacker.getName() + " dealt " + value + "DMG to " + entity.getName() + "!");
        }
    }
    public static void takeDamage(Entity entity, Entity attacker, int value) {
        if (value >= 1) {
            entity.subHP(value - entity.getDEF() );
            if (value < 0) {
                value = 0;
            }
            System.out.println(attacker.getName() + " dealt " + value + "DMG to " + entity.getName() + "!");
        }
    }
    
    // Filters out all non-integer characters from user input
    public static int playerIntChoose(String choose) {
        choose = choose.replaceAll(".*[a-z].*", "");
        choose = choose.replaceAll(".*[!@#$%&*()_+=|<>?{}\\[\\]~].*", "");
        if (choose.contains("\\") ) {
            return 2763;
        }
        else if (choose.matches(".*\\d.*") ) {
            if (choose.indexOf("-") != choose.lastIndexOf("-")) {
                choose = choose.replaceAll("-", "");
                String tempChoose = "-" + choose;
                choose = tempChoose;
            }
            // System.out.println(Integer.parseInt(choose));
            return Integer.parseInt(choose);
        }
        else {
            System.out.println("Invalid option");
        }
        return -1;
    }
    
    // Forces the user to perform a skill check
    public static int doSkillCheck(Ability ability) {
        System.out.println("Get ready...");
        int skillInt = random.nextInt(122-97+1) + 97; // 97-122
        char skillString = (char)skillInt;
        delayTime(700);
        
        long skillStart = System.currentTimeMillis();
        System.out.println("TYPE LETTER: " + skillString);
        String choose = input.nextLine().toLowerCase();
        char chooseChar = choose.charAt(0);
        if (chooseChar == skillString) {
            double skillTime = durationInSec(skillStart);
            double crt1 = ability.getCTime();
            double crt2 = ability.getSTime();
            System.out.println(skillTime + " | [" + crt1 + " | " + crt2 + "]");
            if (skillTime <= crt1) {
                System.out.println("CRTIICAL HIT!");
                return 3;
            }
            else if (skillTime <= crt2) {
                System.out.println("Success!");
                return 2;
            }
            else {
                System.out.println("Too late");
                return 1;
            }
        }
        else {
            System.out.println("Failure...");
        }
        return 0;
        
    }
    
    // Returns how much time has passed from startTime to now
    public static double durationInSec(long startTime) {
        double duration = System.currentTimeMillis() - startTime;
        return duration / 1000;
    }
    
    // Returns placement in the enemy Array of a certain enemy
    public static int getEnemyOrder(String name) {
        for (Enemy en : enemyParty) {
            if (en.getName().equals(name)) {
                return enemyParty.indexOf(en) + 1;
            }
        }
        return -1;
    }
    
    // Sets values of certain variables depending on Ability's variables
    public static void conditionFromAbility(Ability ability) {
        if (ability.getCTime() <= 0 && ability.getSTime() <= 0) {
            skillCheck = false;
        }
        else {
            skillCheck = true;
        }
        attacking = ability.getOffense();
        AOE = ability.getAOE();
    }
    
    // Delays the program by a certain amount of time
    public static void delayTime(int time) {
        try {
            Thread.sleep(time);
        }
        catch (Exception e) {
        }
    }
    
    // Returns whether or not all enemies are below 0HP / dead
    public static boolean isEnemyDead() {
        int enemiesDead = 0;
        for (Enemy en : enemyParty) {
            if (en.getHP() <= 0) {
               enemiesDead++;
            }
        }
        if (enemiesDead >= enemyParty.size()) {
            return true;
        }
        return false;
    }
    
    // Moves onto the next level, or floor
    public static void nextFloor() {
        turnNum = 1;
        floorNum++;
        System.out.println("You beat Floor " + floorNum + "!");
        if ( (floorNum+1) % 3 == 0 && choices.size() > 0) {
            newAbility(choices);
        }
        if (floorNum % 4 == 0) {
            player.setMaxMana(player.getMaxMana() + 2);
            for (Enemy en : enemyParty) {
                en.setDMG(en.getDMG() + 1);
            }
            System.out.println("Enemies deal more damage. Be careful!");
        }
        if (floorNum % 5 == 0) {
            player.setMaxHP(player.getMaxHP() + 5);
        }
        
        for (Enemy en : enemyParty) {
            en.setMaxHP(en.getMaxHP() + 2);
            en.setHP(en.getMaxHP() );
        }
        System.out.println("Onto the next floor! \n");
    }
    
    public static void newAbility(ArrayList<Ability> choices) {
        System.out.println("Choose an ability to gain:");
        for (int i = 1; i <= choices.size(); i++) {
            Ability ability = choices.get(i-1);
            System.out.println("[" + i + "] " + ability );
        }
        int ab_choice = -1;
        while (ab_choice <= -1 || ab_choice > choices.size() ) {
            choose = input.nextLine();
            ab_choice = playerIntChoose(choose);
            System.out.println(ab_choice);
        }
        moveset.add(choices.get(ab_choice-1) );
    }
    
    // Player reaches 0HP
    public static void deathPlayer() {
        if(player.getHP() <= 0) {
            System.out.println("You fainted...");
            System.out.println("You conquered " + (floorNum - 1) + " floors before dying!");
            System.out.println("Play again? [Y / N]");
            while (gameRunning) {
                String again = input.nextLine().toUpperCase();
                char playAgain = again.charAt(0);
                if (playAgain == 'Y') {
                    gameRunning = true;
                }
                else if (playAgain == 'N') {
                    gameRunning = false;
                }
                else {
                    System.out.println("Invalid option");
                }
                    
            }
        }
        
    }

}