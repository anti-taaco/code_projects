package Abilities;

public class Counter extends Ability{
    
    // CONSTRUCTOR
    public Counter() {
        super("Counter", 2, 6, 2, 0.7, 1.2, true, false);
    }
    
    // Prints information
    public String toString() {
        return super.getName() + " [" + super.getCost() + "MP] - Block " + (int)super.getValue() + "DMG and return damage taken";
    }
    
    // Returns total value of the ability
    public int useAbility(int state) {
        if (state == 3) {
            return (int)(getValue() + getCrit() );
        }
        else if (state == 2) {
            return (int)getValue();
        }
        else if (state == 1) {
            return 0;
        }
        return 0;
    }
}