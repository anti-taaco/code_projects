package Abilities;

public class Bomb extends Ability {
    
    // CONSTRUCTOR
    public Bomb() {
        super("Bomb", 1, 2, 2, 0.75, 1.3, true, true);
    }
    
    // Prints information
    public String toString() {
        return super.getName() + " [" + super.getCost() + "MP] - " + (int)super.getValue() + "DMG to all enemies";
    }
    
    // Returns total value of the ability
    public int useAbility(int state) {
        if (state == 3) {
            return (int)(getValue() * getCrit());
        }
        else if (state == 2) {
            return (int)getValue();
        }
        else if (state == 1) {
            return (int)(getValue() / 2 );
        }
        return 0;
    }
}