package Abilities;

public class Slash extends Ability {
    
    // CONSTRUCTOR
    public Slash() {
        super("Slash", 2, 0, 1.5, 0.8, 1.4, true, false);
    }
    
    // Prints information
    public String toString() {
        return super.getName() + " - Deal " + (int)super.getValue() + "DMG";
    }
    
    // Returns total value of the ability
    public int useAbility(int state) {
        if (state == 3) {
            return (int)(getValue() * getCrit());
        }
        else if (state == 2) {
            return (int)getValue();
        }
        else if (state == 1) {
            return (int)(getValue() / 2 );
        }
        return 0;
    }
}