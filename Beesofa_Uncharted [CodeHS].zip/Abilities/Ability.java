package Abilities;

import java.util.ArrayList;

public class Ability {
    private int id;
    private String name;
    private double value;
    private int cost;
    private double crit;
    private double critTime;
    private double skillTime;
    private boolean offense;
    private boolean aoe;
    
    // CONSTRUCTOR
    public Ability(String aName, double val, int co, double cr, double crtime, double skitime, 
    boolean off, boolean area) {
        name = aName;
        value = val;
        cost = co;
        crit = cr;
        critTime = crtime;
        skillTime = skitime;
        offense = off;
        aoe = area;
    }
    
    // GETTER METHODS
    public String getName() {
        return name;
    }
    public double getValue() {
        return value;
    }
    public int getCost() {
        return cost;
    }
    public double getCrit() {
        return crit;
    }
    public double getCTime() {
        return critTime;
    }
    public double getSTime() {
        return skillTime;
    }
    public boolean getOffense() {
        return offense;
    }
    public boolean getAOE() {
        return aoe;
    }
    
    // FUNCTIONS
    // Checks if the player has enough mana to use the ability
    public boolean enoughMana(int mana){
        if (mana >= cost) {
            return true;
        }
        System.out.println("Not enough mana");
        return false;
    }
    public void useAbility() {
        System.out.println("non");
    }
    
}