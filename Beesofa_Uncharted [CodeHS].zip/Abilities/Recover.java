package Abilities;

public class Recover extends Ability {
    
    // CONSTRUCTOR
    public Recover() {
        super("Recover", 6, 5, 1.5, 0, 1.2, false, false);
    }
    
    // Prints information
    public String toString() {
        return super.getName() + " [" + super.getCost() + "MP] - Heal " + (int)super.getValue() + "HP";
    }
    
    // Returns total value of the ability
    public int useAbility(int state) {
        if (state == 3 || state == 2) {
            return (int)getValue();
        }
        return 0;
    }
}