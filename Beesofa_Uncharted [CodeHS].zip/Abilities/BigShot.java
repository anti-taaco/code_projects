package Abilities;

public class BigShot extends Ability {
    
    // CONSTRUCTOR
    public BigShot() {
        super("Big Shot", 2, 4, 3, 0.65, 1, true, false);
    }
    
    // Prints information
    public String toString() {
        return super.getName() + " [" + super.getCost() + "MP] - " + (int)super.getCrit() + "x Crit, lower skill check time";
    }
    
    // Returns total value of the ability
    public int useAbility(int state) {
        if (state == 3) {
            return (int)(getValue() * getCrit());
        }
        else if (state == 2) {
            return (int)getValue();
        }
        else if (state == 1) {
            return (int)(getValue() / 2 );
        }
        return 0;
    }
}