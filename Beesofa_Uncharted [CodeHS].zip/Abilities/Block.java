package Abilities;

public class Block extends Ability{
    
    // CONSTRUCTOR
    public Block() {
        super("Block", 1, 0, 2, 0.7, 1.3, false, false);
    }
    
    // Prints information
    public String toString() {
        return super.getName() + " - Defend against " + (int)super.getValue() + "DMG & gain 2MP";
    }
    
    // Returns total value of the ability
    public int useAbility(int state) {
        if (state == 3) {
            return (int)(getValue() * getCrit());
        }
        else if (state == 2) {
            return (int)getValue();
        }
        else if (state == 1) {
            return 0;
        }
        return 0;
    }
}