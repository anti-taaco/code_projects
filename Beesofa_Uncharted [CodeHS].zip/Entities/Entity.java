package Entities;
import java.util.Random;

public class Entity {
    static Random random = new Random();
    
    private String name;
    private int maxHealth;
    private int health;
    private int damage;
    private int defense;
    
    // CONSTRUCTORS
    public Entity(String na, int hp) {
        name = na;
        maxHealth = hp;
        health = maxHealth;
        damage = 0;
        defense = 0;
    }
    public Entity(String na, int hp, int dmg, int def) {
        name = na;
        maxHealth = hp;
        health = maxHealth;
        damage = dmg;
        defense = def;
    }
    
    // GETTER METHODS
    public String getName() {
        return name;
    }
    public int getMaxHP() {
        return maxHealth;
    }
    public int getHP() {
        return health;
    }
    public int getDMG() {
        return damage;
    }
    public int getDEF() {
        return defense;
    }
    public boolean isDead() {
        if (health <= 0) {
            return true;
        }
        return false;
    }
    
    // SETTER METHODS
    public void setName(String na) {
        name = na;
    }
    public void setMaxHP(int maxHP) {
        maxHealth = maxHP;
    }
    public void setHP(int hp) {
        health = hp;
    }
    public void setDMG(int value) {
        damage = value;
    }
    public void setDEF(int value) {
        defense = value;
    }
    
    // METHODS
    public void addDMG(int value) {
        damage += value;
    }
    public void addDEF(int value) {
        defense += value;
    }
    public void addHP(int value) {
        health += value;
    }
    
    public void subHP(int value) {
        if (value >= 0) {
            health -= value;
        }
    }
    
    public double rollCrit(double crit, int chance) {
        int value = random.nextInt(99)+1;
        if (value >= chance) {
            return crit;
        }
        return 1;
    }

    
}