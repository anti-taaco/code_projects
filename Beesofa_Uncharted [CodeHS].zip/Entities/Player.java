package Entities;

public class Player extends Entity {
    private String face;
    private int maxMana;
    private int mana;
    
    // CONSTRUCTOR
    public Player(String na, String fa, int hp, int ma) {
        super (na, hp);
        face = fa;
        maxMana = ma;
        mana = maxMana;
    }
    
    // GETTER METHODS
    public int getMaxMana() {
        return maxMana;
    }
    public int getMana() {
        return mana;
    }
    
    public void setMaxMana(int value) {
        maxMana = value;
    }
    public void setMana(int value) {
        if (value < maxMana) {
            mana = value;
        }
    }
    
    // FUNCTIONS
    // Changes face based on current health
    public void setFace() {
        if (getHP() > getMaxHP() / 2) {
            face = "( ^ - ^ )";
        }
        else if (getHP() > getMaxHP() / 4) {
            face = "( 0 . < )";
        }
        else {
            face = "( O _ Q )";
        }
    }
    
    // Prints player information
    public void printStatus() {
        setFace();
        System.out.println(getName() + "  " + face);
        System.out.println("Health: " + getHP() + "/" + getMaxHP());
        System.out.println("Mana: " + mana + "/" + maxMana);
    }
}