package Entities;

public class Enemy extends Entity {
    private int minDMG;
    private int maxDMG;

    public Enemy(String na, int hp, int dmg, int def) {
        super(na, hp, dmg, def);
    }
    
    // GETTER METHODS
    public int getMinDMG() {
        return minDMG;
    }
    public int getMaxDMG() {
        return maxDMG;
    }
    
    // Prints enemy information
    public void printStatus(int order) {
        System.out.print("[" + order + "] ");
        System.out.print(getName() + " ");
        System.out.println("[" + getHP() + "/" + getMaxHP() + "HP]");
    }
}