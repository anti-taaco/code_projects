// A recreation of Minesweeper in Java
// Eden Chi, 5/19/2025

import java.util.Scanner;

public class Minesweeper
{
    public static void main(String[] args)
    {
        // Declare and initializes variables
        Scanner input = new Scanner(System.in);
        Grid grid = new Grid();
        int move = 1;
        long startTime = 0;
        boolean gameRunning = true;
        boolean win = false;
        boolean flagging = false;
        
        // Asks the user if they want to use custom settings and let them set them
        System.out.println("Use custom Minesweeper settings? [Y] for Yes");
        String choice = input.nextLine();
        if (choice.toUpperCase().charAt(0) == 'Y') {
            System.out.println("How many rows?");
            int rowNum = input.nextInt();
            input.nextLine();
            System.out.println("How many columns?");
            int colNum = input.nextInt();
            System.out.println("How many mines?");
            int mineNum = input.nextInt();
            grid = new Grid(rowNum, colNum, mineNum);
        }
        System.out.println("\n");
        
        // Runs game
        System.out.println("MINESWEEPER \n");
        System.out.println(grid);
        while (gameRunning) {
            // Displays time taken, grid, if flag is toggled, and mines flagged
            System.out.println("[" + currentTime(startTime) + "]");
            if (move > 1) {
                System.out.println("[Mines: " + (grid.getMines()-grid.getFlaggedSpaces() ) + "]");
            }
            grid.printGrid(false);
            System.out.print("Enter 99 to toggle flag ");
            
            // Prompts user to enter a row and column
            while (true) {
                if (flagging) {
                    System.out.println("[FLAG ON]");
                }
                else {
                    System.out.println("[FLAG OFF]");
                }
                System.out.println("Enter a row: ");
                int row = input.nextInt();
                System.out.println("Enter a column: ");
                int col = input.nextInt();
                input.nextLine();
                System.out.println("Checking Space (" +row + ", " + col + ")..." );
                
                // [ EVALUATION ]
                if (row == 2763 || col == 2763) {  // Auto-quit
                    System.out.println("GetRect() noob");
                    gameRunning = false;
                    break;
                }
                // Checks if your chosen space is within the array
                else if ( (row > -1 && row <= grid.getGrid().length-1) &&
                (col > -1 && col <= grid.getGrid()[0].length-1) ) {  //
                    if (flagging == true) {
                        boolean notRevealed = grid.flagSpace(row, col);
                        if (notRevealed) {
                            break;
                        }
                        else {
                            System.out.println("This space has already been revealed!");
                        }
                        
                    }
                    else if (grid.getFlagGrid(row, col) == false) {
                        if (move <= 1) {
                            int[][] mineSpaces = grid.generateMines(row, col);
                            // print2DArray(mineSpaces);
                            grid.setBoard(mineSpaces);
                            startTime = System.currentTimeMillis();
                        }
                        int space = grid.revealSpace(row, col);
                        // System.out.println(space);
                        if (space == 9) {   // Game dies if chosen space is a mine
                            gameRunning = false;
                        }
                        if (space != 11) {   // Go onto next move if you reveal a new space
                            break;
                        }
                        else {   // Prints if chosen space is already revealed
                            System.out.println("This space has already been revealed!");
                        }
                    }
                    else {   // Prints if chosen space is flagged
                        System.out.println("This space is flagged. Unflag to reveal!");
                    }
                }
                // Checks for 99 in either answer and if found, toggles flag mode
                else if (row == 99 || col == 99) {
                    flagging = ! flagging;
                }
                else {   // Prints when any other number is entered
                    System.out.println("Invalid answer");
                }
            }
            // Adds 1 move and checks for the win condition of all revealed safe spaces
            move++;
            if (grid.getRemainingSpaces() <= 0) {
                gameRunning = false;
                win = true;
            }
            System.out.println();
            
        }
        
        // [ POST-GAME ]
        if (win == false) {
            System.out.println("You lost!");
        }
        else {
            System.out.println("Congratulations! YOU WON!!!!!!!!!!");
        }
        System.out.println("Moves used: " + (move-1) );
        System.out.println("Time spent: " + currentTime(startTime) );
        grid.printGrid(true);
    }
    
    // [ STATIC METHODS ]
    // Converts milliseconds into seconds
    public static double timeInSeconds(long startTime) {
        double time = System.currentTimeMillis() - startTime;
        return time / 1000;
    }
    // Calculates time spent between the parameter and now
    public static String currentTime(long startTime) {
        if (startTime == 0) {
            return "0:00";
        }
        double timeSpent = timeInSeconds(startTime);
        int minutes = (int)timeSpent / 60;
        String ze = "";
        if (timeSpent < 10) {
            ze += "0";
        }
        return minutes + ":" + ze + "" + (int)(timeSpent - (minutes*60) );
    }
    
    // Prints arrays
    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");    
        }
        System.out.println();
        
    }
    public static void printArray(boolean[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");    
        }
        System.out.println();
        
    }
    
    // Prints 2D arrays
    public static void print2DArray(int[][] array) {
        for (int r = 0; r < array.length; r++) {
            printArray(array[r]);
        }
        System.out.println();
    }
    public static void print2DArray(boolean[][] array) {
        for (int r = 0; r < array.length; r++) {
            printArray(array[r]);
        }
        System.out.println();
    }
    
}