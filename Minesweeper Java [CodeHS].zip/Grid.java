public class Grid {
    
    private int[][] grid; // 9 = mine
    private boolean[][] seenGrid; // true if revealed
    private boolean[][] flagGrid; // true if flagged
    private int mines; // total amount of mines
    
    // Constructor for custom settings
    public Grid(int r, int c, int m) {
        grid = new int[r][c];
        seenGrid = new boolean[r][c];
        flagGrid = new boolean[r][c];
        mines = m;
    }
    // Constructor for default settings
    public Grid() {
        int n = 8;
        grid = new int[n][n];
        seenGrid = new boolean[n][n];
        flagGrid = new boolean[n][n];
        mines = 10;
    }
    
    // [ GETTER METHODS ]
    public int[][] getGrid() {
        return grid; // entire grid
    }
    public int getGrid(int r, int c) {
        return grid[r][c]; // specific grid space
    }
    
    public boolean[][] getSeenGrid() {
        return seenGrid; // entire grid with revealed / unrevealed spaces
    }
    public boolean getSeenGrid(int r, int c) {
        return seenGrid[r][c]; // if specific space is revealed or not
    }
    
    public boolean[][] getFlagGrid() {
        return flagGrid; // entire grid with flagged / unflagged spaces
    }
    public boolean getFlagGrid(int r, int c) {
        return flagGrid[r][c]; // if specific space is flagged or not
    }
    
    public int getMines() {
        return mines; // total amount of mines
    }
    // Gets amount of flagged spaces
    public int getFlaggedSpaces() {
        int flagged = 0;
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid.length; c++) {
                if (flagGrid[r][c] == true) {
                    flagged++;
                }
                
            }
        }
        return flagged;
    }
    // Gets remaining safe spaces
    public int getRemainingSpaces() {
        int remaining = 0;
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid.length; c++) {
                if (grid[r][c] != 9 && seenGrid[r][c] == false) {
                    remaining++;
                }
                
            }
        }
        return remaining;
    }
    
    // [ SETTER METHODS ]
    public void setGrid(int r, int c) {
        grid = new int[r][c];
    }
    public void setGridSpace(int r, int c, int num) {
        grid[r][c] = num;
    }
    public void setSeenSpace(int r, int c, boolean hide) {
        seenGrid[r][c] = hide;
    }
    public void setMines(int m) {
        mines = m;
    }
    
    // [ GRID MODIFICATION / PRINTING ]
    // Prints the grid. If showAnswers is false, hide all unrevealed numbers and mines
    public void printGrid(boolean showAnswers) {
        System.out.print("  ");
        for (int i = 0; i < grid.length; i++) {
            if (i / 10 == 0) {
                System.out.print(" ");
            }
            System.out.print("  " + i);
        }
        System.out.println();
        
        for (int r = 0; r < grid.length; r++) {
            System.out.print(r);
            if (r / 10 == 0) {
                System.out.print(" ");
            }
            
            for (int c = 0; c < grid[r].length; c++) {
                System.out.print(" | ");
                if (showAnswers == false) {
                    if (flagGrid[r][c] == true) {
                        System.out.print("F");
                    }
                    else if (seenGrid[r][c] == false) {
                        System.out.print(".");
                    }
                }
                if (showAnswers == true || (seenGrid[r][c] == true && flagGrid[r][c] == false) ) {
                    if (grid[r][c] == 9) {
                        System.out.print("*");
                    }
                    else if (grid[r][c] == 0) {
                        System.out.print(" ");
                    }
                    else {
                        System.out.print(grid[r][c]);
                    }
                }
            }
            System.out.println();
        }
    }
    
    // Reveals the targetted space and adjacent spaces if they equal 0
    // Returns 11 if it's already been revealed / flagged, or another number if not
    public int revealSpace(int r, int c) {
        if (!seenGrid[r][c] && !flagGrid[r][c]) {
            seenGrid[r][c] = true;
            if (grid[r][c] == 0) {
                revealAdjacentSpaces(r, c);
            }
            return grid[r][c];
        }
        return 11;
    }
    // Flags or unflags the targetted space, returns false is space has been revealed
    public boolean flagSpace(int r, int c) {
        if (seenGrid[r][c] == false) {
            flagGrid[r][c] = !(flagGrid[r][c]);
            return true;
        }
        return false;
    }
    // Reveals spaces around the targetted space
    public void revealAdjacentSpaces(int row, int col) {
        for (int r = -1; r < 2; r++ ) {
            for (int c = -1; c < 2; c++ ) {
                int checkedRow = row+r;
                int checkedCol = col+c;
                boolean checkSpace = true;
                if (checkedRow < 0 || checkedRow >= grid.length) {
                    checkSpace = false;
                }
                if (checkedCol < 0 || checkedCol >= grid.length) {
                    checkSpace = false;
                }
                
                if (checkSpace) {
                    if (checkAdjacentSpaces(checkedRow, checkedCol) <= 8) {
                        revealSpace(checkedRow, checkedCol);
                    }
                    
                }
                
            }
        }
    }
    
    // [ BOARD GENERATION ]
    // Generates random spaces to be set as mines, checks for duplicates
    public int[][] generateMines(int r, int c) {
        int[][] chosenMines = new int[mines][2];
        for (int i = 0; i < mines; i++) {
            int row = (int)(Math.random() * grid.length);
            int col = (int)(Math.random() * grid[0].length);
            System.out.println(row + " " + col);
            
            boolean equal = false;
            for (int j = 0; j < i; j++) {
                if (row == chosenMines[j][0] && col == chosenMines[j][1]) {
                    equal = true;
                    break;
                }
            }
            if (row == r && col == c) {
                equal = true;
            }
            if (equal) {
                i--;
            }
            else {
                chosenMines[i][0] = row;
                chosenMines[i][1] = col;
            }
        }
        return chosenMines;
    }
    
    // Sets the grid with all the mines and numbers
    public void setBoard(int[][] chosenMines) {
        for (int i = 0; i < chosenMines.length; i++) {
            int cRow = chosenMines[i][0];
            int cCol = chosenMines[i][1];
            grid[cRow][cCol] = 9;
        }
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                if (grid[r][c] != 9) {
                    grid[r][c] = checkAdjacentSpaces(r, c);
                }
            }
        }
    }
    
    // Checks spaces around the target for mines, adding up how many mines around it
    public int checkAdjacentSpaces(int row, int col) {
        int num = 0;
        for (int r = -1; r < 2; r++ ) {
            for (int c = -1; c < 2; c++ ) {
                int checkedRow = row+r;
                int checkedCol = col+c;
                boolean checkSpace = true;
                if (checkedRow < 0 || checkedRow >= grid.length) {
                    checkSpace = false;
                }
                if (checkedCol < 0 || checkedCol >= grid.length) {
                    checkSpace = false;
                }
                
                if (checkSpace && grid[checkedRow][checkedCol] == 9) {
                    num++;
                }
            }
        }
        return num;
    }
    
    // Returns the size of the grid and amount of mines
    public String toString() {
        return "Grid Size: " + grid.length + "x" + grid[0].length +
        "\nTotal Mines: " + mines;
    }
    
}